package com.example.ettaki;

import android.app.TimePickerDialog;

import java.sql.Timestamp;

public class Note {
    String title;
    String description;
    String time;
    String Date;

    public Note(){

    }



    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }





}


