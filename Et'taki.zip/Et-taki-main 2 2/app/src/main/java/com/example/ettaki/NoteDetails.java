package com.example.ettaki;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.DocumentReference;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;

public class NoteDetails extends AppCompatActivity {


    EditText titleInput, DescriptionInput, timeButton, dateButtom;
    MaterialButton saveBtn;
    TextView pageTitle;
    String title , description , time, date, docId;
    boolean isEditMode ;
    TextView deleteNote;

    DatePickerDialog datePickerDialog;
    int hour, minute;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);

        timeButton = findViewById(R.id.timePickerDialog);
        dateButtom = findViewById(R.id.datePickerDialog);

        isEditMode = false;
        pageTitle = findViewById(R.id.page_title);
        titleInput = findViewById(R.id.titleinput);
        DescriptionInput = findViewById(R.id.descriptioninput);
        saveBtn = findViewById(R.id.savebtn);
        deleteNote = findViewById(R.id.delete_note);


        timeButton.setOnClickListener((v)-> {
            TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
                hour = selectedHour;
                minute= selectedMinute;
                timeButton.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));

            }
        };
            int style = AlertDialog.THEME_HOLO_DARK;
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,style, onTimeSetListener, hour, minute, true);
            timePickerDialog.setTitle("الوقت ");
            timePickerDialog.show();
        });

        dateButtom.setOnClickListener((v)->{
            DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int day) {
                    month= month+1;
                    String date = makeDateString(day,month,year);
                    dateButtom.setText(date);
                }
            };
            Calendar cal = Calendar.getInstance();
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_MONTH);

            int style = AlertDialog.THEME_HOLO_DARK;
            datePickerDialog= new DatePickerDialog(this, style, onDateSetListener, year,month,day);
            datePickerDialog.show();

        });


        //recevive data
        title = getIntent().getStringExtra("title");
        description = getIntent().getStringExtra("description");
        time = getIntent().getStringExtra("time");
        date = getIntent().getStringExtra("date");
        docId = getIntent().getStringExtra("docId");

        if(docId != null && !docId.isEmpty()){
            isEditMode =true;

        }

        titleInput.setText(title);
        DescriptionInput.setText(description);
        timeButton.setText(time);
        dateButtom.setText(date);
        if(isEditMode){
            pageTitle.setText("تحرير مذه الملاحظة ");
            deleteNote.setVisibility(View.VISIBLE);
        }


        saveBtn.setOnClickListener((v)-> saveNote());
        deleteNote.setOnClickListener((v) -> deleteNoteFromFir());

    }

    private String makeDateString(int day, int month, int year) {
        return  getMonthFormat(month) + " "+ day + " " + year;
    }

    private String getMonthFormat(int month) {
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEB";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "APR";
        if(month == 5)
            return "MAY";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AUG";
        if(month == 9)
            return "SEP";
        if(month == 10)
            return "OCT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEC";
        return "JAN";

    }


    void saveNote(){
        String noteTitle = titleInput.getText().toString();
        String noteDesc = DescriptionInput.getText().toString();
        String notetime = timeButton.getText().toString();
        String noteDate = dateButtom.getText().toString();

        if(noteTitle == null || noteTitle.isEmpty()){
            titleInput.setError("قم بادخال عنوان الملاحظة");
            return;

        }

        Note note = new Note();
        note.setTitle(noteTitle);
        note.setDescription(noteDesc);
        note.setTime(notetime);
        note.setDate(noteDate);



        saveNoteToFirebase(note);
    }

    void saveNoteToFirebase(Note note){
        DocumentReference documentReference;
        if(isEditMode){
            //update note
            documentReference = ForNote.getCollectionReferenceForNotes().document(docId);

        }else {
            //creat new note
            documentReference = ForNote.getCollectionReferenceForNotes().document();

        }


        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(getApplicationContext(), "تم اضافة الملاحظة بنجاح ", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(getApplicationContext(), "حدث خطا! حاول مره اخرى ", Toast.LENGTH_LONG).show();


                }

            }
        });

    }

    void deleteNoteFromFir(){
        DocumentReference documentReference;
        documentReference = ForNote.getCollectionReferenceForNotes().document(docId);


        documentReference.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(getApplicationContext(), "تم حذف الملاحظة بنجاح ", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(getApplicationContext(), "حدث خطا! حاول مره اخرى ", Toast.LENGTH_LONG).show();


                }

            }
        });

    }

//
//    public String openTimePicker() {
//        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
//            @Override
//            public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
//                hour = selectedHour;
//                minute= selectedMinute;
//                timeButton.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
//
//            }
//        };
//        int style = AlertDialog.THEME_HOLO_DARK;
//        TimePickerDialog timePickerDialog = new TimePickerDialog(this,style, onTimeSetListener, hour, minute, true);
//        timePickerDialog.setTitle("الوقت ");
//        timePickerDialog.show();
//        String time = timePickerDialog.toString();
//        return time;
//
//
//    }
}