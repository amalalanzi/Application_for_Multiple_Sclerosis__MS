package com.example.ettaki;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.ettaki.chat.models.UsersModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class profile extends AppCompatActivity {

    private FirebaseUser user;
    private DatabaseReference reference;

    private FirebaseDatabase database;
    private DatabaseReference userRef;
    private static final String USER = "User";


    private String userID;

    private TextView UserName, UserEmail, UserType, logout, Name, txtTestLevel;
    ImageView back, imageProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Name = (TextView) findViewById(R.id.Name);
        back = (ImageView) findViewById(R.id.back);
        imageProfile = (ImageView) findViewById(R.id.imagepro);

        UserName = (TextView) findViewById(R.id.fullName);
        UserEmail = (TextView) findViewById(R.id.userEmail);
        UserType = (TextView) findViewById(R.id.UserType);
        logout = (TextView) findViewById(R.id.logout);
        txtTestLevel = findViewById(R.id.txtTestLevel);


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), login.class));
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity2.class));
            }
        });


        database = FirebaseDatabase.getInstance();
        userRef = database.getReference(USER);
        user = FirebaseAuth.getInstance().getCurrentUser();
        userID = user.getUid();

        UsersModel usersModel = new UsersModel();
        usersModel.setEmail(user.getEmail());

        userRef.orderByChild("email").equalTo(user.getEmail()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {
                    for (DataSnapshot ds : snapshot.getChildren()) {

                        String firstName = ds.child("firstName").getValue(String.class);
                        String lastName = ds.child("lastName").getValue(String.class);
                        String email = ds.child("email").getValue(String.class);
                        String type = ds.child("type").getValue(String.class);
                        String image = ds.child("image").getValue(String.class);
                        String test = ds.child("test").getValue(String.class);


                        Name.setText("مرحبا, " + firstName + "!");
                        String fullName = firstName + " " + lastName;

                        UserName.setText(fullName);
                        UserEmail.setText(email);
                        UserType.setText(type);
                        if (test == null || test.equals("")) {
                            txtTestLevel.setText("الرجاء اجراء اختبار");

                        } else {
                            txtTestLevel.setText(test);
                        }

                        Glide.with(getApplicationContext())
                                .load(image)
                                .centerCrop()
                                .placeholder(R.drawable.profile2)
                                .into(imageProfile);


                    }
                }
                else {
                    Toast.makeText(getApplicationContext(), "fullName:not exists", Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    //
//        userRef.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    for (DataSnapshot ds : snapshot.getChildren()){
//
////                        String firstName =ds.child("firstName").getValue(String.class);
////                        String lastName= ds.child("lastName").getValue(String.class);
////                        String email= ds.child("email").getValue(String.class);
////                        String type= ds.child("type").getValue(String.class);
////                        String image= ds.child("image").getValue(String.class);
////
////
////                        Name.setText("Welcome, " + firstName + "!");
////                        String fullName = firstName + " " + lastName;
////                        UserName.setText(fullName);
//                        UserEmail.setText(ds.child("email").getValue(String.class));
//                        UserType.setText(ds.child("type").getValue(String.class));
//
//                    }
//                }
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });


//        reference = FirebaseDatabase.getInstance().getReference("User");
//


//
//        reference.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                UsersModel userProfile =new UsersModel();
//
//
//
//                // email,firstName,lastName,type, gender, password,image,status,userId
//                if (snapshot.exists()) {
//                    //avatarImageView.setText(avatar);
//
//                    for (DataSnapshot item : snapshot.getChildren()) {
//                        //Save user in local Shared memory
//                       // userProfile.setPassword(item.child("password").getValue().toString());
//                        //profile_image
//                        UserEmail.setText( item.child("email").getValue(String.class));
//
//                         String firstName =item.child("firstName").getValue().toString();
//                        String lastName= item.child("lastName").getValue().toString();
//                        //register_dat
//                        userProfile.setEmail(item.child("email").getValue().toString());
//                        userProfile.setType(item.child("type").getValue().toString());
//
//
//                        Name.setText("Welcome, " + firstName + "!");
//                        String fullName = firstName + " " + lastName;
//                        UserName.setText(fullName);
//
////                        typeTextView.setText(type);
//
//
//                    }
//
//
//
////
//               }
////
////                UsersModel userProfile = snapshot.getValue(UsersModel.class);
////                if(userProfile != null) {
////
////                    String firstName = userProfile.getFirstName();
////                    String lastName = userProfile.getLastName();
////                    String email = userProfile.getEmail();
////                    String type = userProfile.getType();
////                    //String avatar = userProfile.avatar;
////
////                    //    Name.setText("Welcome, " + firstName + "!");
////                    String fullName = firstName + " " + lastName;
////                    UserName.setText(fullName);
////                    UserEmail.setText(email);
////
////                }
//
//                }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText( getApplicationContext(), "هناك خطأ ما !", Toast.LENGTH_LONG).show();
//
//            }
//        });
//
//
//
//

    //  menu();
}


//
//    private void getUserProfile(FirebaseUser user) {
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("User");
//        usersModel.setEmail(user.getEmail());
//        myRef.orderByChild("email").equalTo(user.getEmail())
//                .addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        if (snapshot.exists()) {
//                            for (DataSnapshot item : snapshot.getChildren()) {
//                                //Save user in local Shared memory
//                                usersModel.setPassword(item.child("password").getValue().toString());
//                                //profile_image
//                                userModel.setProfile_image(item.child("profile_image").getValue().toString());
//                                userModel.setUser_name(item.child("user_name").getValue().toString());
//                                //register_date
//                                userModel.setRegister_date(item.child("register_date").getValue().toString());
//
//                            }
//                            showProfileInfo(userModel);
//                        } else {
//                            Toast.makeText(getApplicationContext(), "لايوجد بيانات", Toast.LENGTH_LONG).show();
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//                        pDialog.dismiss();
//                    }
//                });
//    }

//
//    public void menu(){
//
//        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
//        NavigationView navigationView = findViewById(R.id.navigationView);
//        findViewById(R.id.imageMenu).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                drawerLayout.openDrawer(GravityCompat.START);
//            }
//        });
//
//        navigationView = findViewById(R.id.navigationView);
//        navigationView.setItemIconTintList(null);
//        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                switch (item.getItemId()){
//                    case R.id.menuProfile: {
//                        Intent intent = new Intent(getApplicationContext(), profile.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuHome: {
//                        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuUs: {
//                        Intent intent = new Intent(getApplicationContext(), aboutUs.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuPositive: {
//                        Intent intent = new Intent(getApplicationContext(), positive.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuChat: {
//                        Intent intent = new Intent(getApplicationContext(), ChatActivity.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuReminder: {
//                        Intent intent = new Intent(getApplicationContext(), reminders.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuُTest: {
//                        Intent intent = new Intent(getApplicationContext(), startTest.class);
//                        startActivity(intent);
//                        break;
//                    }
//
//                    case R.id.menuExersice: {
//                        Intent intent = new Intent(getApplicationContext(), doExercises.class);
//                        startActivity(intent);
//                        break;
//                    }
//                }
//                return false;
//            }
//        });
//    }


